import "./App.css";
import Reserve from "./components/Reserve";

function App() {
  return (
    <div className="App">
      <Reserve />
    </div>
  );
}

export default App;
